for i in [1,2,1]:
    print ("El valor de i es: ", (i+2))
for i in "amigo":
    print("Este  caracater es: ", (i))
n=int(input("Dame un número: \n"))
while (n%2!=0):
    n=int(input("Dame otro número: \n"))
print(f"El número {n} es par")
    