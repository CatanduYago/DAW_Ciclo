nombre=input("Ingrese su nombre: ")
print (nombre)