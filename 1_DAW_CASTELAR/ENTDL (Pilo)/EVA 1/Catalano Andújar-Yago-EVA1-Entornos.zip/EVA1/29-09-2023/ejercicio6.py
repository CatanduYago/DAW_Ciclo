nom=input("Introduce tu nombre: ")
ape=input("Introduce tus apellidos: ")
print(f"Hola, {nom} {ape}")