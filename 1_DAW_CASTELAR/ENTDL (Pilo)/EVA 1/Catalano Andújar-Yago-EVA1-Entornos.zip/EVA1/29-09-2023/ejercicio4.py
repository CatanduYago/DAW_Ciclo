resultado=500+50+5
print("El resultado es:",resultado)