num=input('Escriba un numero de dos cifras: ')
int(primernum = num [0])
int(segundonum = num [1])
resultado = primernum+segundonum
if num % 2 == 0:
    print ("La suma de", num, "es par y es ", resultado)
else: print("La suma de", num, "es impar y es ", resultado)