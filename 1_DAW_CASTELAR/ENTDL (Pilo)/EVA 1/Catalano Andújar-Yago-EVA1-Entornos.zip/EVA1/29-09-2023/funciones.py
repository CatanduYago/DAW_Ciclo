#cadena = input("Ingrese una cadena: ")
# pasar a mayusculas.
#print(cadena.upper())
#cadena = input("Ingrese una cadena en mayúsculas: ")
# pasar a minusculas.
#print(cadena.lower())
#la primera letra en mayúsculas.
#cadena = input("Ingrese una cadena: ")
#print(cadena.capitalize())
#contar los caracteres de una cadena o caracter en un texto.
cadena = input("Ingrese una cadena: ")
num_caracteres=cadena.count("de")
print(num_caracteres)

