import java.util.Scanner;

public class JuegoDeLaVida {
    private int rows;
    private int cols;
    private boolean[][] grid;
    private boolean[][] generacion;

    public JuegoDeLaVida(int rows, int cols) {

        this.rows = rows;
        this.cols = cols;
        this.grid = new boolean[rows][cols];
        this.generacion = new boolean[rows][cols];
    }

    public void random() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Escribe la densidad de celulas vivas siendo 0 ninguna y 1 todas siguiendo el formato '0,X'");
        Double densidad = sc.nextDouble();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                grid[i][j] = Math.random() < densidad;           //Este numerin es el que elige la cantidad de casillas vivas contra las muertas iniciales
            }
        }
    }

    public void generacion( ) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int vivos = countvivos(i, j);

                if (grid[i][j]) {

                    if (vivos < 2 || vivos > 3) {
                        generacion[i][j] = false;
                    } else {
                        generacion[i][j] = true;
                    }
                } else {

                    if (vivos == 3) {
                        generacion[i][j] = true;
                    } else {
                        generacion[i][j] = false;
                    }
                }
            }
        }
        for (int i = 0; i < rows; i++) {
            System.arraycopy(generacion[i], 0, grid[i], 0, cols);
        }
        
    }

    public int countvivos(int row, int col) {
        int contador = 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (i == 0 && j == 0) {
                    continue;
                }

                int rowsvivos = row + i;
                int colsvivos = col + j;

                if (rowsvivos >= 0 && rowsvivos < rows && colsvivos >= 0 && colsvivos < cols) {
                    if (grid[rowsvivos][colsvivos]) {
                        contador++;
                    }
                }
            }
        }
        return contador;
    }

    public void matriz() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(grid[i][j] ? "█" : "░");
            }
            System.out.println();
        }
        System.out.println();

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Escribe la altura");
        int rows = sc.nextInt();
        System.out.println("Escribe el ancho");
        int cols = sc.nextInt();
        System.out.println("Escribe el numero de generaciones deseadas");
        int generaciones = sc.nextInt();
        JuegoDeLaVida game = new JuegoDeLaVida(rows, cols);
        game.random();

        for (int generacion = 1; generacion <= generaciones; generacion++) {      // Aquie esta el numero de generaciones que se desean
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.print("\033[H\033[2J");
            System.out.println("Generacion: " + generacion);
            game.matriz();
            game.generacion();

        }
        
    }
}