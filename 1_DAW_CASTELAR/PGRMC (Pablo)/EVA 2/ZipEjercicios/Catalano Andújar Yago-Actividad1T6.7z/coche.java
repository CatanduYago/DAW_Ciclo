public class coche {

    public String modelo;
    public String matricula;

public coche(String modelo, String matricula) {
    this.modelo = modelo;
    this.matricula = matricula;
    }

public String getModelo() {
    return modelo;
    }

public void setModelo(String modelo) {
    this.modelo = modelo;
    }

public String getMatricula() {
    return matricula;
    }

public void setMatricula(String matricula) {
    this.matricula = matricula;
    }
}