public class libro {

    public static String nombre;
    public String autor;

public libro(String nombre, String autor) {
    this.nombre = nombre;
    this.autor = autor;
    }

public String getNombre() {
    return nombre;
    }

public void setNombre(String nombre) {
    this.nombre = nombre;
    }

public String getAutor() {
    return autor;
    }

public void setAutor(String autor) {
    this.autor = autor;
    }

}