public class Pila {
    Nodo cima;

    public Pila(){
        this.cima = null;
    }


    public int pop(){
        if (cima==null){
            return -1;
        }
        else {
            int contenido = cima.getContenido();
            cima = cima.getNodoSiguiente();
            return contenido;
        }
    }
    public int peek(){
        if (cima==null){
            return -1;
        }
        else{
            return cima.getContenido();
        }
    }
}
