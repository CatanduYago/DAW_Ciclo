public interface aprobable {

    void aprobar();    
}
