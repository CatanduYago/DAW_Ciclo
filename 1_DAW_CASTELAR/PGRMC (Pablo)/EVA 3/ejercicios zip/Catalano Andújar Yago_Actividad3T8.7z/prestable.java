public interface prestable {
    void prestar();

    void devolver();

    boolean prestado();
    
}
