public class Actividad4 {
    public static void main(String[] args) {
                /*long.MAX_VALUE representa el valor máximo que puede tener un dato long */        
                long maxInt = Long.MAX_VALUE;
                /* Imprime el maximo valor */
                System.out.println("El número entero más grande posible en Java es: " + maxInt);
            }

        }