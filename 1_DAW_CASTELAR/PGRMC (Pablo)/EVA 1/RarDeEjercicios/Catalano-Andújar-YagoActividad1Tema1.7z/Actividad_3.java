public class Actividad_3 {
    public static void main(String[] args) {
        System.out.print("Palabra en Inglés");
        System.out.print("\t"); 
        System.out.println("Traducción al Español");
        System.out.println("-----------------------------------");
        
        System.out.print("apple");
        System.out.print("\t\t\t");
        System.out.println("manzana");
        
        System.out.print("car");
        System.out.print("\t\t\t"); 
        System.out.println("coche");
        
        System.out.print("house");
        System.out.print("\t\t\t"); 
        System.out.println("casa");
        
        System.out.print("dog");
        System.out.print("\t\t\t"); 
        System.out.println("perro");
        
        System.out.print("book");
        System.out.print("\t\t\t"); 
        System.out.println("libro");
        
        System.out.print("computer");
        System.out.print("\t\t"); 
        System.out.println("ordenador");
        
        System.out.print("table");
        System.out.print("\t\t\t");
        System.out.println("mesa");
        
        System.out.print("pen");
        System.out.print("\t\t\t"); 
        System.out.println("bolígrafo");
        
        System.out.print("school");
        System.out.print("\t\t\t"); 
        System.out.println("escuela");
        
        System.out.print("cat");
        System.out.print("\t\t\t"); 
        System.out.println("gato");
    }
}
