public class Actividad_1_2 {
    public static void main(String[] args) throws Exception {
        System.out.println("Yago Catalano");
        System.out.println("19 años");
        System.out.println("ycatalanoa01@educarex.es");
    }
}