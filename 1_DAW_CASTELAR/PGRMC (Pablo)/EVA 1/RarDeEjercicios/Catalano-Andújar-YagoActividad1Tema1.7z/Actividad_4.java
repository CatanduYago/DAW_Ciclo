public class Actividad_4 {
    public static void main(String[] args) {
        System.out.println("Día\t\tHora\t\t\tMateria");
        System.out.println("------------------------------------------------------------------");

        System.out.println("Lunes\t\t15:30 - 16:25\t\tSSINF");
        System.out.println("\t\t16:25 - 17:20\t\tGRMC");
        System.out.println("\t\t17:20 - 18:15\t\tPGRMC");
        System.out.println("\t\t18:45 - 19:40\t\tFOL");
        System.out.println("\t\t19:40 - 20:35\t\tLMSGI");
        System.out.println("\t\t20:35 - 21:30\t\tLMSGI\n");

        System.out.println("Martes\t\t16:25 - 17:20\t\tFOL");
        System.out.println("\t\t16:25 - 17:20\t\tBBDD");
        System.out.println("\t\t17:20 - 18:15\t\tBBDD");
        System.out.println("\t\t18:45 - 19:40\t\tSSINF");
        System.out.println("\t\t19:40 - 20:35\t\tENTDL");
        System.out.println("\t\t20:35 - 21:30\t\tENTDL\n");


        System.out.println("Miércoles\t15:30 - 16:25\t\tPGRMC");
        System.out.println("\t\t16:25 - 17:20\t\tPGRMC");
        System.out.println("\t\t17:20 - 18:15\t\tPGRMC");
        System.out.println("\t\t18:45 - 19:40\t\tSSINF");
        System.out.println("\t\t19:40 - 20:35\t\tBBDD");
        System.out.println("\t\t20:35 - 21:30\t\tBBDD\n");
        
        System.out.println("Jueves\t\t15:30 - 16:25\t\tPGRMC");
        System.out.println("\t\t16:25 - 17:20\t\tPGRMC");
        System.out.println("\t\t17:20 - 18:15\t\tLMSGI");
        System.out.println("\t\t18:45 - 19:40\t\tLMSGI");
        System.out.println("\t\t19:40 - 20:35\t\tSSINF");
        System.out.println("\t\t20:35 - 21:30\t\tSSINF\n");

        System.out.println("Viernes\t\t15:30 - 16:25\t\tENTDL");
        System.out.println("\t\t16:25 - 17:20\t\tENTDL");
        System.out.println("\t\t17:20 - 18:15\t\tFOL");
        System.out.println("\t\t18:45 - 19:40\t\tSSINF");
        System.out.println("\t\t19:40 - 20:35\t\tBBDD");
        System.out.println("\t\t20:35 - 21:30\t\tBBDD\n");
    
    }
}
